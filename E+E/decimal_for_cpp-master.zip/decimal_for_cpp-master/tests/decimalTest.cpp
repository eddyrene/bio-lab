/////////////////////////////////////////////////////////////////////////////
// Name:        decimalTest.cpp
// Purpose:     Test decimal type.
// Author:      Piotr Likus
// Modified by:
// Created:     31/10/2010
// Licence:     BSD
/////////////////////////////////////////////////////////////////////////////

#define BOOST_TEST_NO_MAIN
#define BOOST_TEST_MODULE DecimalTest
#include <boost/test/included/unit_test.hpp>

#include "decimalTest.ipp"

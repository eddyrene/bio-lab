/////////////////////////////////////////////////////////////////////////////
// Name:        decimalTest.cpp
// Purpose:     Test decimal type - I/O functions.
// Author:      Piotr Likus
// Modified by:
// Created:     18/06/2012
// Licence:     BSD
/////////////////////////////////////////////////////////////////////////////

#define BOOST_TEST_NO_MAIN
#define BOOST_TEST_MODULE DecimalTestIo
#include <boost/test/included/unit_test.hpp>

#include "decimalTestIo.ipp"
